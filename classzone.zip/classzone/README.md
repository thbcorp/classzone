# 🎮 ClassZone - Mini Game Zone

A web-based mini-game zone for students, featuring responsive design, touch/keyboard support, and online leaderboards.

## 🚀 Features

- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Touch & Keyboard Support**: Full compatibility with touchscreens and keyboards
- **Online Leaderboards**: Firebase or Supabase integration for score tracking
- **Two Mini-Games**:
  - 🧀 **Cheese Clicker**: Click the cheese to earn points
  - 📚 **Homework Dodge**: Dodge falling homework assignments
- **Modern UI**: Beautiful gradient design with smooth animations

## 📁 Project Structure

```
classzone/
├── index.html              # Main homepage
├── css/
│   └── style.css          # Responsive CSS styles
├── js/
│   ├── main.js            # Main application logic
│   └── api.js             # Firebase/Supabase integration
├── games/
│   ├── cheese.html        # Cheese Clicker game
│   └── dodge.html         # Homework Dodge game
├── assets/                # Images and other assets
└── README.md              # This file
```

## 🛠️ Setup Instructions

### 1. Database Setup (Choose One)

#### Option A: Firebase Setup

1. **Create Firebase Project**:
   - Go to [Firebase Console](https://console.firebase.google.com)
   - Click "Create a project"
   - Follow the setup wizard

2. **Enable Firestore Database**:
   - In your Firebase project, go to "Firestore Database"
   - Click "Create database"
   - Choose "Start in test mode" (for development)
   - Select a location for your database

3. **Get Firebase Config**:
   - Go to Project Settings (gear icon)
   - Scroll down to "Your apps"
   - Click "Web" icon to add a web app
   - Copy the config object

4. **Update Configuration**:
   - Open `js/api.js`
   - Replace the Firebase config with your actual config:
   ```javascript
   firebase: {
       apiKey: "your-actual-api-key",
       authDomain: "your-project.firebaseapp.com",
       projectId: "your-actual-project-id",
       storageBucket: "your-project.appspot.com",
       messagingSenderId: "your-sender-id",
       appId: "your-app-id"
   }
   ```

5. **Create Firestore Collection**:
   - In Firestore Database, create a collection called "scores"
   - No specific document structure needed (it will be created automatically)

#### Option B: Supabase Setup

1. **Create Supabase Project**:
   - Go to [Supabase](https://supabase.com)
   - Sign up and create a new project
   - Wait for the project to be ready

2. **Create Scores Table**:
   - Go to "Table Editor" in your Supabase dashboard
   - Click "New Table"
   - Name it "scores"
   - Add these columns:
     - `id` (int8, primary key, auto-increment)
     - `gameId` (text)
     - `username` (text)
     - `score` (int8)
     - `timestamp` (timestamptz)
   - Click "Save"

3. **Get Supabase Config**:
   - Go to Settings > API
   - Copy your "Project URL" and "anon public" key

4. **Update Configuration**:
   - Open `js/api.js`
   - Replace the Supabase config:
   ```javascript
   supabase: {
       url: "https://your-project.supabase.co",
       key: "your-actual-anon-key"
   }
   ```

5. **Switch Provider**:
   - In `js/api.js`, change `this.provider = 'firebase'` to `this.provider = 'supabase'`

### 2. GitHub Pages Deployment

1. **Create GitHub Repository**:
   - Go to [GitHub](https://github.com)
   - Click "New repository"
   - Name it `classzone` (or any name you prefer)
   - Make it public
   - Don't initialize with README (we already have files)

2. **Upload Files to GitHub**:
   ```bash
   # Initialize git repository
   git init
   
   # Add all files
   git add .
   
   # Commit files
   git commit -m "Initial commit: ClassZone mini-game zone"
   
   # Add remote repository (replace with your GitHub username)
   git remote add origin https://github.com/YOUR_USERNAME/classzone.git
   
   # Push to GitHub
   git push -u origin main
   ```

3. **Enable GitHub Pages**:
   - Go to your repository on GitHub
   - Click "Settings" tab
   - Scroll down to "Pages" section
   - Under "Source", select "Deploy from a branch"
   - Choose "main" branch and "/ (root)" folder
   - Click "Save"
   - Wait a few minutes for deployment

4. **Access Your Site**:
   - Your site will be available at: `https://YOUR_USERNAME.github.io/classzone/`

### 3. Custom Domain (Optional)

1. **Buy a Domain**:
   - Purchase a domain from providers like Namecheap, GoDaddy, etc.

2. **Configure DNS**:
   - Add a CNAME record pointing to `YOUR_USERNAME.github.io`

3. **Update GitHub Pages**:
   - In your repository settings, add your custom domain
   - GitHub will provide instructions for DNS configuration

## 🔧 Local Development

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/classzone.git
   cd classzone
   ```

2. **Open in Browser**:
   - Simply open `index.html` in your web browser
   - Or use a local server:
   ```bash
   # Using Python
   python -m http.server 8000
   
   # Using Node.js
   npx http-server
   
   # Using PHP
   php -S localhost:8000
   ```

3. **Test Features**:
   - Test both games
   - Verify touch/keyboard controls
   - Check leaderboard functionality
   - Test responsive design on different screen sizes

## 🎮 Game Controls

### Cheese Clicker
- **Mouse/Touch**: Click the cheese button
- **Keyboard**: Space or Enter to click
- **Objective**: Click as many times as possible

### Homework Dodge
- **Mouse**: Move mouse to control student
- **Touch**: Touch and drag to control student
- **Keyboard**: Arrow keys to move, Space to pause
- **Objective**: Dodge falling homework as long as possible

## 🛡️ Security Notes

- **Firebase**: Uses Firestore security rules (configure in Firebase Console)
- **Supabase**: Uses Row Level Security (configure in Supabase dashboard)
- **Local Storage**: Fallback when database is unavailable
- **Input Validation**: All user inputs are validated and sanitized

## 🐛 Troubleshooting

### Common Issues:

1. **Leaderboard not loading**:
   - Check browser console for errors
   - Verify database configuration
   - Ensure database permissions are set correctly

2. **Games not working on mobile**:
   - Check if touch events are properly handled
   - Verify viewport meta tag is present
   - Test on different devices

3. **GitHub Pages not updating**:
   - Wait 5-10 minutes for changes to propagate
   - Check if files are properly committed and pushed
   - Verify GitHub Pages settings

### Debug Mode:
- Open browser developer tools
- Check Console tab for JavaScript errors
- Check Network tab for failed requests

## 📱 Browser Support

- **Desktop**: Chrome, Firefox, Safari, Edge
- **Mobile**: iOS Safari, Chrome Mobile, Samsung Internet
- **Features**: Touch events, Canvas API, Local Storage

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🎯 Future Enhancements

- [ ] More mini-games
- [ ] User authentication
- [ ] Achievement system
- [ ] Sound effects
- [ ] Multiplayer support
- [ ] Progressive Web App (PWA) features

---

**Built with ❤️ for students everywhere!**
