# 🚀 Supabase Setup Guide for ClassZone

This guide will walk you through setting up Supabase for your ClassZone mini-game zone.

## 📋 Prerequisites

- A GitHub account
- A Supabase account (free tier available)

## 🔧 Step-by-Step Setup

### 1. Create Supabase Project

1. **Go to Supabase**:
   - Visit [https://supabase.com](https://supabase.com)
   - Click "Start your project"
   - Sign up or log in with GitHub

2. **Create New Project**:
   - Click "New Project"
   - Choose your organization
   - Enter project details:
     - **Name**: `classzone` (or any name you prefer)
     - **Database Password**: Create a strong password (save this!)
     - **Region**: Choose closest to your users
   - Click "Create new project"
   - Wait 2-3 minutes for setup to complete

### 2. Create the Scores Table

1. **Open Table Editor**:
   - In your Supabase dashboard, click "Table Editor" in the sidebar
   - Click "New Table"

2. **Configure Table**:
   - **Table name**: `scores`
   - **Description**: `Game scores and leaderboard data`

3. **Add Columns**:
   Click "Add Column" for each of these:

   | Column Name | Type | Default Value | Nullable | Primary Key |
   |-------------|------|---------------|----------|-------------|
   | `id` | `int8` | `auto-increment` | ❌ | ✅ |
   | `gameId` | `text` | - | ❌ | ❌ |
   | `username` | `text` | - | ❌ | ❌ |
   | `score` | `int8` | - | ❌ | ❌ |
   | `timestamp` | `timestamptz` | `now()` | ❌ | ❌ |

4. **Save Table**:
   - Click "Save" to create the table

### 3. Get Your Supabase Credentials

1. **Go to Settings**:
   - Click the gear icon (⚙️) in the sidebar
   - Click "API"

2. **Copy Your Credentials**:
   - **Project URL**: Copy the URL (looks like `https://abcdefgh.supabase.co`)
   - **anon public key**: Copy the long key (starts with `eyJ...`)

### 4. Update Your ClassZone Configuration

1. **Open `js/api.js`**:
   - Find the `supabase` configuration section
   - Replace the placeholder values:

   ```javascript
   supabase: {
       url: "https://YOUR_PROJECT_ID.supabase.co",  // Your Project URL
       key: "YOUR_ANON_KEY_HERE"                   // Your anon public key
   }
   ```

2. **Example Configuration**:
   ```javascript
   supabase: {
       url: "https://abcdefghijklmnop.supabase.co",
       key: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiY2RlZmdoaWprbG1ub3AiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTYzNDU2Nzg5MCwiZXhwIjoxOTUwMTQzODkwfQ.example_key_here"
   }
   ```

### 5. Configure Row Level Security (RLS)

1. **Enable RLS**:
   - Go to "Authentication" → "Policies"
   - Find your `scores` table
   - Click "Enable RLS"

2. **Create Policies**:
   - Click "New Policy" for the `scores` table
   - **Policy name**: `Allow public read and insert`
   - **Policy definition**:
     ```sql
     (true)
     ```
   - **Allowed operation**: `All`
   - Click "Save"

### 6. Test Your Setup

1. **Open Your ClassZone**:
   - Open `index.html` in your browser
   - Open browser developer tools (F12)
   - Check the Console tab for any errors

2. **Test Leaderboard**:
   - Play a game and get a score
   - Try to save your score
   - Check if the leaderboard loads

3. **Verify in Supabase**:
   - Go back to your Supabase dashboard
   - Check the `scores` table
   - You should see your test data

## 🚀 Deploy to GitHub Pages

### 1. Create GitHub Repository

1. **Go to GitHub**:
   - Visit [https://github.com](https://github.com)
   - Click "New repository"

2. **Repository Settings**:
   - **Repository name**: `classzone`
   - **Description**: `Mini Game Zone for Students`
   - **Visibility**: Public
   - **Initialize**: Don't check any boxes
   - Click "Create repository"

### 2. Upload Your Files

```bash
# In your classzone folder, run these commands:

# Initialize git
git init

# Add all files
git add .

# Commit files
git commit -m "Initial ClassZone commit with Supabase integration"

# Add your GitHub repository (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/classzone.git

# Push to GitHub
git push -u origin main
```

### 3. Enable GitHub Pages

1. **Go to Repository Settings**:
   - In your GitHub repository, click "Settings"
   - Scroll down to "Pages" section

2. **Configure Pages**:
   - **Source**: Deploy from a branch
   - **Branch**: `main`
   - **Folder**: `/ (root)`
   - Click "Save"

3. **Access Your Site**:
   - Wait 2-3 minutes for deployment
   - Your site will be at: `https://YOUR_USERNAME.github.io/classzone/`

## 🔍 Troubleshooting

### Common Issues:

1. **"Failed to initialize Supabase"**:
   - Check your URL and key in `js/api.js`
   - Verify your Supabase project is active
   - Check browser console for specific errors

2. **"Error saving score"**:
   - Verify RLS policies are set correctly
   - Check if the `scores` table exists
   - Ensure your anon key has the right permissions

3. **Leaderboard not loading**:
   - Check network tab in developer tools
   - Verify Supabase connection
   - Check if data exists in the `scores` table

### Debug Steps:

1. **Check Browser Console**:
   - Open Developer Tools (F12)
   - Look for red error messages
   - Check Network tab for failed requests

2. **Verify Supabase Setup**:
   - Go to your Supabase dashboard
   - Check if the `scores` table has data
   - Verify your API credentials

3. **Test Locally First**:
   - Test everything on your local machine
   - Use `python -m http.server 8000` to serve locally
   - Fix any issues before deploying

## 🎯 Next Steps

1. **Customize Your Games**:
   - Add more mini-games
   - Modify game mechanics
   - Update styling

2. **Enhance Features**:
   - Add user authentication
   - Implement achievements
   - Add sound effects

3. **Monitor Usage**:
   - Check Supabase dashboard for user activity
   - Monitor performance
   - Gather user feedback

## 📞 Support

If you encounter issues:

1. **Check Supabase Documentation**: [https://supabase.com/docs](https://supabase.com/docs)
2. **GitHub Issues**: Create an issue in your repository
3. **Community**: Join the Supabase Discord community

---

**🎮 Your ClassZone is now ready with Supabase integration!**
