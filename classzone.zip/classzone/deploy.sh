#!/bin/bash

# ClassZone Deployment Script
echo "🎮 ClassZone Deployment Script"
echo "================================"

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "Initializing git repository..."
    git init
fi

# Add all files
echo "Adding files to git..."
git add .

# Commit changes
echo "Committing changes..."
git commit -m "Update ClassZone: $(date)"

# Check if remote exists
if ! git remote | grep -q origin; then
    echo "Please add your GitHub repository as origin:"
    echo "git remote add origin https://github.com/YOUR_USERNAME/classzone.git"
    echo "Then run this script again."
    exit 1
fi

# Push to GitHub
echo "Pushing to GitHub..."
git push origin main

echo "✅ Deployment complete!"
echo "Your site should be available at: https://YOUR_USERNAME.github.io/classzone/"
echo ""
echo "Next steps:"
echo "1. Set up Firebase or Supabase for leaderboards"
echo "2. Update js/api.js with your database configuration"
echo "3. Test your games on different devices"
