// API Integration for ClassZone - Supabase Configuration
class ClassZoneAPI {
    constructor() {
        this.config = {
            // Supabase Configuration (replace with your actual config)
            supabase: {
                url: "https://your-project.supabase.co",
                key: "your-anon-key"
            }
        };
        
        this.provider = 'supabase'; // Using Supabase for ClassZone
        this.db = null;
        this.init();
    }

    async init() {
        try {
            await this.initSupabase();
        } catch (error) {
            console.error('Failed to initialize Supabase:', error);
            // Fallback to localStorage
            this.provider = 'localStorage';
            console.log('Falling back to localStorage');
        }
    }

    async initSupabase() {
        // Load Supabase SDK
        if (typeof supabase === 'undefined') {
            await this.loadScript('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2');
        }

        this.db = supabase.createClient(this.config.supabase.url, this.config.supabase.key);
        
        // Test connection
        const { data, error } = await this.db.from('scores').select('count').limit(1);
        if (error && error.code !== 'PGRST116') { // PGRST116 is "relation does not exist" which is expected initially
            throw error;
        }
    }

    loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    async saveScore(gameId, username, score) {
        const scoreData = {
            gameId,
            username: username.trim(),
            score: parseInt(score),
            timestamp: new Date().toISOString()
        };

        try {
            if (this.provider === 'supabase') {
                return await this.saveScoreSupabase(scoreData);
            } else {
                return this.saveScoreLocalStorage(scoreData);
            }
        } catch (error) {
            console.error('Error saving score:', error);
            // Fallback to localStorage
            return this.saveScoreLocalStorage(scoreData);
        }
    }

    async saveScoreSupabase(scoreData) {
        const { data, error } = await this.db
            .from('scores')
            .insert([scoreData])
            .select();
        
        if (error) throw error;
        return data[0].id;
    }

    saveScoreLocalStorage(scoreData) {
        const scores = this.getLocalScores();
        scores.push(scoreData);
        scores.sort((a, b) => b.score - a.score);
        scores.splice(100); // Keep only top 100
        localStorage.setItem('classzone_scores', JSON.stringify(scores));
        return 'local_' + Date.now();
    }

    async getLeaderboard(gameId = null, limit = 10) {
        try {
            if (this.provider === 'supabase') {
                return await this.getLeaderboardSupabase(gameId, limit);
            } else {
                return this.getLeaderboardLocalStorage(gameId, limit);
            }
        } catch (error) {
            console.error('Error getting leaderboard:', error);
            // Fallback to localStorage
            return this.getLeaderboardLocalStorage(gameId, limit);
        }
    }

    async getLeaderboardSupabase(gameId, limit) {
        let query = this.db
            .from('scores')
            .select('*')
            .order('score', { ascending: false })
            .limit(limit);
        
        if (gameId) {
            query = query.eq('gameId', gameId);
        }

        const { data, error } = await query;
        if (error) throw error;
        return data;
    }

    getLeaderboardLocalStorage(gameId, limit) {
        const scores = this.getLocalScores();
        let filteredScores = gameId ? scores.filter(s => s.gameId === gameId) : scores;
        return filteredScores.slice(0, limit);
    }

    getLocalScores() {
        const stored = localStorage.getItem('classzone_scores');
        return stored ? JSON.parse(stored) : [];
    }

    async getHighScore(gameId) {
        const leaderboard = await this.getLeaderboard(gameId, 1);
        return leaderboard.length > 0 ? leaderboard[0].score : 0;
    }

    async getPlayerCount(gameId) {
        try {
            if (this.provider === 'supabase') {
                const { count, error } = await this.db
                    .from('scores')
                    .select('*', { count: 'exact', head: true })
                    .eq('gameId', gameId);
                if (error) throw error;
                return count;
            } else {
                const scores = this.getLocalScores();
                return scores.filter(s => s.gameId === gameId).length;
            }
        } catch (error) {
            console.error('Error getting player count:', error);
            return 0;
        }
    }
}

// Create global API instance
window.api = new ClassZoneAPI();
