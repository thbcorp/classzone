// ClassZone Main JavaScript
class ClassZone {
    constructor() {
        this.games = [
            {
                id: 'cheese',
                title: 'Cheese Clicker',
                description: 'Click the cheese to earn points! How many can you collect?',
                icon: '🧀',
                file: 'games/cheese.html',
                color: '#ff6b6b'
            },
            {
                id: 'dodge',
                title: 'Homework Dodge',
                description: 'Dodge the falling homework assignments! Stay alive as long as possible.',
                icon: '📚',
                file: 'games/dodge.html',
                color: '#4ecdc4'
            }
        ];
        
        this.init();
    }

    init() {
        this.renderGameCards();
        this.setupEventListeners();
        this.setupTouchSupport();
        this.setupKeyboardSupport();
    }

    renderGameCards() {
        const gamesGrid = document.getElementById('gamesGrid');
        gamesGrid.innerHTML = '';

        this.games.forEach(game => {
            const gameCard = this.createGameCard(game);
            gamesGrid.appendChild(gameCard);
        });
    }

    createGameCard(game) {
        const card = document.createElement('div');
        card.className = 'game-card';
        card.style.borderColor = game.color;
        card.setAttribute('data-game', game.id);
        
        card.innerHTML = `
            <div class="game-icon">${game.icon}</div>
            <h3 class="game-title">${game.title}</h3>
            <p class="game-description">${game.description}</p>
            <div class="game-stats">
                <span>High Score: <span id="high-score-${game.id}">Loading...</span></span>
                <span>Players: <span id="player-count-${game.id}">-</span></span>
            </div>
        `;

        // Add event listeners for both click and touch
        this.addGameCardListeners(card, game);
        
        return card;
    }

    addGameCardListeners(card, game) {
        // Click event
        card.addEventListener('click', (e) => {
            e.preventDefault();
            this.openGame(game);
        });

        // Touch events
        card.addEventListener('touchstart', (e) => {
            e.preventDefault();
            card.style.transform = 'scale(0.95)';
        });

        card.addEventListener('touchend', (e) => {
            e.preventDefault();
            card.style.transform = '';
            this.openGame(game);
        });

        // Prevent default touch behavior
        card.addEventListener('touchmove', (e) => {
            e.preventDefault();
        });
    }

    openGame(game) {
        // Add loading state
        const card = document.querySelector(`[data-game="${game.id}"]`);
        if (card) {
            card.style.opacity = '0.7';
        }

        // Navigate to game
        window.location.href = game.file;
    }

    setupEventListeners() {
        // Leaderboard modal
        const leaderboardModal = document.getElementById('leaderboardModal');
        const closeModal = document.getElementById('closeModal');

        closeModal.addEventListener('click', () => {
            leaderboardModal.style.display = 'none';
        });

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === leaderboardModal) {
                leaderboardModal.style.display = 'none';
            }
        });

        // Load leaderboard data when modal opens
        leaderboardModal.addEventListener('click', (e) => {
            if (e.target === leaderboardModal) {
                this.loadLeaderboard();
            }
        });
    }

    setupTouchSupport() {
        // Prevent zoom on double tap
        let lastTouchEnd = 0;
        document.addEventListener('touchend', (e) => {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                e.preventDefault();
            }
            lastTouchEnd = now;
        }, false);

        // Prevent context menu on long press
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
    }

    setupKeyboardSupport() {
        document.addEventListener('keydown', (e) => {
            // ESC key to close modals
            if (e.key === 'Escape') {
                const modal = document.getElementById('leaderboardModal');
                if (modal.style.display === 'block') {
                    modal.style.display = 'none';
                }
            }

            // Number keys to open games (1, 2, etc.)
            const gameIndex = parseInt(e.key) - 1;
            if (gameIndex >= 0 && gameIndex < this.games.length) {
                this.openGame(this.games[gameIndex]);
            }
        });
    }

    async loadLeaderboard() {
        const leaderboard = document.getElementById('leaderboard');
        leaderboard.innerHTML = '<div class="loading"></div> Loading leaderboard...';

        try {
            const scores = await api.getLeaderboard();
            this.displayLeaderboard(scores);
        } catch (error) {
            console.error('Error loading leaderboard:', error);
            leaderboard.innerHTML = '<p>Error loading leaderboard. Please try again later.</p>';
        }
    }

    displayLeaderboard(scores) {
        const leaderboard = document.getElementById('leaderboard');
        
        if (!scores || scores.length === 0) {
            leaderboard.innerHTML = '<p>No scores yet! Be the first to play!</p>';
            return;
        }

        leaderboard.innerHTML = scores.map((score, index) => `
            <div class="leaderboard-entry">
                <div class="rank">#${index + 1}</div>
                <div class="player-info">
                    <div class="player-name">${score.username}</div>
                </div>
                <div class="player-score">${score.score}</div>
            </div>
        `).join('');
    }

    // Method to update high scores (called by games)
    updateHighScore(gameId, score) {
        const highScoreElement = document.getElementById(`high-score-${gameId}`);
        if (highScoreElement) {
            highScoreElement.textContent = score;
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.classZone = new ClassZone();
    
    // Load initial high scores
    classZone.loadLeaderboard();
});
